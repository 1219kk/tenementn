// 接口
import axios from 'axios'
const instance = axios.create({
  baseURL: 'http://liufusong.top:8080/',
  timeout: 5000
  // 五秒没访问到重新访问
})
export default instance
