<template>
  <div>
    <van-popup v-model="show" position="top" style="height: 100%">
      <van-nav-bar
        title="标题"
        left-text="返回"
        left-arrow
        @click-left="show = false"
      />
      <van-index-bar>
        <van-index-anchor index="A" />
        <van-cell title="文本" />
        <van-cell title="文本" />
        <van-cell title="文本" />

        <van-index-anchor index="B" />
        <van-cell title="文本" />
        <van-cell title="文本" />
        <van-cell title="文本" />
      </van-index-bar>
    </van-popup>
  </div>
</template>

<script>
export default {
  created () { },
  data () {
    return {
      show: false
    }
  },
  methods: {
    setShow (show = false) {
      this.show = show
    }
  },
  computed: {},
  watch: {},
  filters: {},
  components: {}
}
</script>

<style scoped lang='less'>
</style>
