<template>
  <div>
    <!-- 标题 -->
    <van-search background="#4fc08d" show-action placeholder="请输入小区或地址">
      <template #left><van-icon name="arrow-left" color="#ffffff" /> </template>
      <template #label>
        <span>
          北京
          <i class="iconfont icon-xiala xiala" @click="showArrow"></i>
        </span>
      </template>
      <template #action>
        <i class="iconfont icon-ditu dt"></i>
      </template>
    </van-search>
    <!-- 吸附van-sticky -->
    <van-sticky>
      <!-- 1 -->
      <van-dropdown-menu :overlay="false">
        <van-dropdown-item title="11">
          <van-picker show-toolbar :columns="columns" />
        </van-dropdown-item>
        <!-- 2 -->
        <van-dropdown-item title="11">
          <van-picker show-toolbar :columns="columns" />
        </van-dropdown-item>
        <!-- 3 -->
        <van-dropdown-item title="11">
          <van-picker show-toolbar :columns="columns" />
        </van-dropdown-item>
        <!-- 4 -->
        <van-dropdown-item title="11" @open="show = true" @close="false">
          <van-popup
            class="MyPopup"
            v-model="show"
            position="right"
            :style="{ width: '80%', height: '100%' }"
            >111111</van-popup
          >
        </van-dropdown-item>
      </van-dropdown-menu>
    </van-sticky>
    <van-card
      num="2"
      price="2.00"
      desc="描述信息"
      title="商品标题"
      thumb="https://img01.yzcdn.cn/vant/ipad.jpeg"
    /><van-card
      num="2"
      price="2.00"
      desc="描述信息"
      title="商品标题"
      thumb="https://img01.yzcdn.cn/vant/ipad.jpeg"
    /><van-card
      num="2"
      price="2.00"
      desc="描述信息"
      title="商品标题"
      thumb="https://img01.yzcdn.cn/vant/ipad.jpeg"
    /><van-card
      num="2"
      price="2.00"
      desc="描述信息"
      title="商品标题"
      thumb="https://img01.yzcdn.cn/vant/ipad.jpeg"
    /><van-card
      num="2"
      price="2.00"
      desc="描述信息"
      title="商品标题"
      thumb="https://img01.yzcdn.cn/vant/ipad.jpeg"
    /><van-card
      num="2"
      price="2.00"
      desc="描述信息"
      title="商品标题"
      thumb="https://img01.yzcdn.cn/vant/ipad.jpeg"
    />
    <my-arrow ref="showarrow"></my-arrow>
  </div>
</template>

<script>
import MyArrow from '@/components/MyArrow.vue'
export default {
  created () { },
  data () {
    return {
      columns: [
        // 第一列
        {
          values: ['周一', '周二', '周三', '周四', '周五'],
          defaultIndex: 2
        },
        // 第二列
        {
          values: ['上午', '下午', '晚上'],
          defaultIndex: 1
        },
        {
          values: ['上午', '下午', '晚上'],
          defaultIndex: 1
        }
      ],
      show: true

    }
  },
  methods: {
    showArrow () {
      this.$refs.showarrow.show = true
    }

  },
  computed: {},
  watch: {},
  filters: {},
  components: { MyArrow }
}
</script>

<style scoped lang='less'>
.dt {
  font-size: 40px;
  color: #fff;
}
.xiala {
  border-right: 1px solid #e5e5e5;
}
/deep/.van-dropdown-menu__bar--opened {
  z-index: 1;
}
 </style>
